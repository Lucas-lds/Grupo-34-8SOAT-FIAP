import json
import boto3
import os
import cpf

# Inicializando o cliente Cognito com especificação da região
cognito_client = boto3.client('cognito-idp', region_name='us-east-1')

def lambda_handler(event, context):
    # Verificar se o CPF foi enviado no evento
    #cpf_number = event.get('cpf')
    # Obtém o CPF a partir do parâmetro de consulta 'cpf'
    cpf_number = event['queryStringParameters'].get('cpf')

    # Se o CPF não for fornecido, retornar erro 400
    if not cpf_number:
        return {
            'statusCode': 400,
            'body': json.dumps('CPF não fornecido')
        }

    # Validar o CPF usando a biblioteca 'cpf'
    if not cpf.checar(cpf_number):
        return {
            'statusCode': 400,
            'body': json.dumps('CPF inválido')
        }

    # Obter o User Pool ID da variável de ambiente
    user_pool_id = os.environ.get('COGNITO_USER_POOL_ID')

    # Se a variável de ambiente do User Pool não estiver configurada, retornar erro 500
    if not user_pool_id:
        return {
            'statusCode': 500,
            'body': json.dumps('User Pool ID não configurado corretamente')
        }

    # Tentar consultar o Cognito usando o CPF fornecido
    try:
        response = cognito_client.list_users(
            UserPoolId=user_pool_id,  # Usando o User Pool ID da variável de ambiente
            Filter=f'custom:cpf="{cpf_number}"',
            Limit=1  # Limitar para 1 usuário
        )

        # Verificar se algum usuário foi encontrado com o CPF fornecido
        if response['Users']:
            return {
                'statusCode': 200,
                'body': json.dumps({'message': 'Usuário autenticado com sucesso'})
            }
        else:
            return {
                'statusCode': 404,
                'body': json.dumps('Usuário não encontrado')
            }

    except cognito_client.exceptions.ClientError as e:
        # Tratar erros do Cognito (por exemplo, falta de permissões ou erro na consulta)
        return {
            'statusCode': 500,
            'body': json.dumps(f'Erro ao consultar o Cognito: {str(e)}')
        }