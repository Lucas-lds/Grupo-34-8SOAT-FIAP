import json
import os
import boto3
from botocore.exceptions import ClientError

cognito_client = boto3.client('cognito-idp', region_name='us-east-1')
user_pool_id = os.environ.get('COGNITO_USER_POOL_ID')

def lambda_handler(event, context):
    body = json.loads(event.get('body', '{}'))
    cpf_number = body.get('cpf', '')

    if not cpf_number:
        return {'statusCode': 400, 'body': json.dumps('CPF não fornecido')}

    if not user_pool_id:
        return {'statusCode': 500, 'body': json.dumps('User Pool ID não configurado corretamente')}

    try:
        response = cognito_client.list_users(
            UserPoolId=user_pool_id,
            Limit=1
        )

        users = response.get('Users', [])

        for user in users:
            attributes = user.get('Attributes', [])
            for attribute in attributes:
                if attribute['Name'] == 'custom:cpf':
                    cpf = attribute['Value']
                    if cpf == cpf_number:
                        # Autentica o usuário e obtém o token JWT
                        auth_response = cognito_client.initiate_auth(
                            AuthFlow='CUSTOM_AUTH',
                            AuthParameters={
                                'USERNAME': user['Username']
                            },
                            ClientId=os.environ.get('COGNITO_CLIENT_ID')
                        )

                        id_token = auth_response['AuthenticationResult']['IdToken']
                        access_token = auth_response['AuthenticationResult']['AccessToken']
                        refresh_token = auth_response['AuthenticationResult']['RefreshToken']

                        return {
                            'statusCode': 200,
                            'body': json.dumps({
                                'message': 'Usuário autenticado com sucesso',
                                'id_token': id_token,
                                'access_token': access_token,
                                'refresh_token': refresh_token
                            })
                        }
                    else:
                        return {
                            'statusCode': 404,
                            'body': json.dumps('Usuário não encontrado.')
                        }

    except ClientError as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Erro ao acessar o Cognito: {str(e)}')
        }