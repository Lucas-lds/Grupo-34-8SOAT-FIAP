import json
import os
import boto3
from botocore.exceptions import ClientError
from datetime import datetime

# Função para converter objetos datetime e outros tipos não serializáveis para JSON
def default_converter(o):
    if isinstance(o, datetime):
        return o.isoformat()  # Converte datetime para string no formato ISO
    raise TypeError(f"Tipo não serializável: {o.__class__.__name__}")  # Levanta erro para tipos não tratados

cognito_client = boto3.client('cognito-idp', region_name='us-east-1')
user_pool_id = os.environ.get('COGNITO_USER_POOL_ID')
client_id = os.environ.get('COGNITO_CLIENT_ID')

def lambda_handler(event, context):
    # Logando o evento para ver como ele chega
    print(f"Evento: {json.dumps(event)}")

        # Verificando se o corpo da requisição está presente
    if 'cpf' not in event or 'password' not in event:
        return {'statusCode': 400, 'body': json.dumps('Corpo da requisição não encontrado.')}
    
    # Obtendo o CPF e a senha do corpo
    cpf_number = event.get('cpf', '')
    password = event.get('password', '')
    
    # Logando o valor do cpf_number e da senha para garantir que estão sendo extraídos corretamente
    print(f"cpf_number: {cpf_number}")
    print(f"password: {password}")

     # Validando se o CPF e a senha foram fornecidos
    if not cpf_number:
        return {'statusCode': 400, 'body': json.dumps('CPF não fornecido')}
    if not password:
        return {'statusCode': 400, 'body': json.dumps('Senha não fornecida')}

    # Verificando se o User Pool ID está configurado
    if not user_pool_id:
        return {'statusCode': 500, 'body': json.dumps('User Pool ID não configurado corretamente')}

    # Verificando se o Client ID está configurado
    if not client_id:
        return {'statusCode': 500, 'body': json.dumps('Client ID não configurado corretamente')}

    try:
        # Usando list_users sem filtro e iterando sobre os usuários para buscar pelo custom:custom:cpf
        response = cognito_client.list_users(
            UserPoolId=user_pool_id,
            Limit=60  # Pode aumentar o limite se tiver muitos usuários
        )

        # Logando o retorno completo da resposta para depuração
        print(f"Resposta do Cognito: {json.dumps(response, default=default_converter)}")

        # Obtendo os usuários encontrados (se houver algum)
        users = response.get('Users', [])

        # Iterando sobre todos os usuários para encontrar o CPF
        user_found = None
        for user in users:
            attributes = user.get('Attributes', [])
            for attribute in attributes:
                if attribute['Name'] == 'custom:custom:cpf' and attribute['Value'] == cpf_number:
                    user_found = user
                    break
            if user_found:
                break

        if not user_found:
            return {'statusCode': 404, 'body': json.dumps('Usuário não encontrado.')}

        # Logando o nome de usuário encontrado e o status do usuário
        print(f"Username encontrado: {user_found['Username']}")
        print(f"Status do usuário: {user_found['UserStatus']}")

        # Realizando a autenticação do usuário usando o fluxo padrão (USER_PASSWORD_AUTH)
        try:
            auth_response = cognito_client.initiate_auth(
                AuthFlow='USER_PASSWORD_AUTH',  # Usando o fluxo padrão de autenticação
                AuthParameters={
                    'USERNAME': user_found['Username'],  # Nome de usuário encontrado
                    'PASSWORD': password  # A senha fornecida no corpo da requisição
                },
                #ClientId=os.environ.get('COGNITO_CLIENT_ID')  # ID do aplicativo Cognito
                ClientId=client_id  # ID do aplicativo Cognito
            )
        except ClientError as e:
            if e.response['Error']['Code'] == 'NotAuthorizedException':
                print(f"Erro de autenticação: {e.response['Error']['Message']}")
                return {'statusCode': 401, 'body': json.dumps('Nome de usuário ou senha incorretos.')}
            else:
                raise e

        # Logando a resposta de autenticação para depuração
        print(f"Resposta de autenticação: {json.dumps(auth_response, default=default_converter)}")

        # Verificando se a autenticação requer mudança de senha
        #if auth_response.get('ChallengeName') == 'NEW_PASSWORD_REQUIRED':
            # Realizando a mudança de senha
            #new_password = event.get('new_password', '')
            #if not new_password:
                #return {'statusCode': 400, 'body': json.dumps('Nova senha não fornecida para o desafio de mudança de senha.')}

            #challenge_response = cognito_client.respond_to_auth_challenge(
                #ClientId=os.environ.get('COGNITO_CLIENT_ID'),
                #ClientId=client_id,
                #ChallengeName='NEW_PASSWORD_REQUIRED',
                #Session=auth_response['Session'],
                #ChallengeResponses={
                    #'USERNAME': user_found['Username'],
                    #'NEW_PASSWORD': new_password
                #}
            #)

            # Verificando se a mudança de senha foi bem-sucedida
            #if 'AuthenticationResult' not in challenge_response:
                #return {'statusCode': 401, 'body': json.dumps('Falha na mudança de senha. Verifique suas credenciais.')}

            # Obtendo os tokens de autenticação após a mudança de senha
            #id_token = challenge_response['AuthenticationResult']['IdToken']
            #access_token = challenge_response['AuthenticationResult']['AccessToken']
            #refresh_token = challenge_response['AuthenticationResult']['RefreshToken']

            #return {
                #'statusCode': 200,
                #'body': json.dumps({
                   # 'message': 'Usuário autenticado com sucesso após mudança de senha',
                    #'id_token': id_token,
                    #'access_token': access_token,
                    #'refresh_token': refresh_token
                #})
           # }

        # Verificando se a autenticação foi bem-sucedida
        if 'AuthenticationResult' not in auth_response:
            return {'statusCode': 401, 'body': json.dumps('Autenticação falhou. Verifique suas credenciais.')}

        # Obtendo os tokens de autenticação
        id_token = auth_response['AuthenticationResult']['IdToken']
        access_token = auth_response['AuthenticationResult']['AccessToken']
        refresh_token = auth_response['AuthenticationResult']['RefreshToken']

        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Usuário autenticado com sucesso',
                'id_token': id_token,
                'access_token': access_token,
                'refresh_token': refresh_token
            })
        }

    except ClientError as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Erro ao acessar o Cognito: {str(e)}')
        }